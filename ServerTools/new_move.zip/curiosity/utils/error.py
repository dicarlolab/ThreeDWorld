class HiLossError(Exception):
  pass


class NoChangeError(Exception):
  pass
